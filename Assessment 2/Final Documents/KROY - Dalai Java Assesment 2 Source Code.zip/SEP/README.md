# Dalai_Java-SEPR

Software Enginerring Project for Second Year Computer Science Students at the University of York.

Develop a game that involves Aliens from the planet of KROY that have invaded York. They are weak to water and so the rebels are using the old fire station as a base. Controll the fire engines to defeat the KROY fortresses and take back control of York.
___
## Team Members

Jack Kershaw  
Max Lloyd  
James Hau  
Peter Clark  
William Marr  
Yuqing Gong  
Thomas Richardson  
