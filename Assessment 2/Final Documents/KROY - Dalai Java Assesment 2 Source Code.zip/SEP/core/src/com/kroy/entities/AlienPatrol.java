package com.kroy.entities;

import com.badlogic.gdx.graphics.Texture;
import com.kroy.game.Point;

public class AlienPatrol extends Unit{

    boolean hunting;
    Point[] patrolRoute;

    /**
     *
     * @param hunting Whether the patrol is aware of the location of the fire station
     * @param patrolRoute  Aids with path finding
     * @param movementSpeed Speed of the patrol
     * @param health Current health of the patrol
     * @param range Max range of the patrols weapons
     * @param position Current position of the alien patrol
     * @param img The texture to be used for the alien patrol
     */
    public AlienPatrol(boolean hunting, Point[] patrolRoute, int movementSpeed, int health, int range, Point position, Texture img){
        super(movementSpeed, health,  range, position, img);
        this.hunting = hunting;
        this.patrolRoute = patrolRoute;
    }

    /** Responsible for reducing the fire stations health.
     *
     * @param fireStation the fire station that the patrol is to attack
     */
    public void attackFireStation(FireStation fireStation){

    }

    /** Path finding towards the firestation
     *
     * @param fireStation the fire station that the patrol is to hunt
     */
    public void huntFireStation(FireStation fireStation){

    }

}
